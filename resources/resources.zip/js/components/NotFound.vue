<template>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10 d-flex" style="background-image: url(/img/undraw_no_data_qbuo.svg); background-repeat: no-repeat; height: 800px !important;">
                <div class="mx-auto pl-5 my-5 py-5">
                    <div class="my-5 pl-4 py-5 text-right text-rtl">
                        <span class="font-20"><i class="fal fa-lightbulb-exclamation"></i>
                            بحش مورد نظر در دست ساخت است.
                        </span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
        }
    }
</script>
