<html>
<header>

   <?php echo $__env->make('layouts.pdfStyle', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</header>
<body style="border: black 10px solid">

<?php
function arabic_w2e($str) {
    $arabic_eastern = array('٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩');
    $arabic_western = array('0', '1', '2', '3', '4', '5', '6', '7', '8', '9');
    return str_replace($arabic_western, $arabic_eastern, $str);
}
?>
<htmlpagefooter name="page-footer">
    <span class="persian-num">{nb}/{PAGENO}</span>
</htmlpagefooter>
<table class="table border table-sm">
    <tr>
        <td colspan="2" style="border: none; font-size: 12pt"><b>مشخصات فردی</b></td>.
        <td rowspan="8" style="border: none; vertical-align: middle; text-align: center">
            <?php if($user->photo == 'profile.png'): ?>
                <img class="img-thumbnail" src="<?php echo e('.'.DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'profile.png'); ?>" alt="" width="100" height="100"> </td>
            <?php else: ?>
                <img class="img-thumbnail" src="<?php echo e('.'.DIRECTORY_SEPARATOR.'img'.DIRECTORY_SEPARATOR.'profile'.DIRECTORY_SEPARATOR."$user->photo"); ?>" alt="" width="100" height="100"> </td>
            <?php endif; ?>
    </tr>
    <tr>
        <td >نام و نام خانوادگی:  <?php echo e($user->profile->Fname.' '.$user->profile->Lname); ?>         </td>
    </tr>
    <tr>
        <td >
            آخرین مدرک: <?php echo e($user->profile->degree->name); ?>

        </td>
    </tr>
    <tr>
        <td >
            دانشکده: <?php echo e($user->profile->faculty->name); ?> <br>
        </td>
    </tr>
    <tr>
        <td >
            گروه: <?php echo e($user->profile->department->name); ?> <br>
        </td>
    </tr>
    <tr>
        <td >
            نوع همکاری: <?php echo e($user->profile->position->name); ?> <br>
        </td>
    </tr>
    <tr>
        <td >
            رایانامه: <?php echo e($user->email); ?> <br>
        </td>
    </tr>
    <tr>
        <td class="persian-num">
            شماره تماس: <?php echo e($user->profile->phone); ?> <br>
        </td>
    </tr>

</table>
<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="12" style="border: none; font-size: 12pt" class="border-bottom"><b>مقالات ژورنالی</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <td style="vertical-align: middle">نام مقاله</td>
        <td style="vertical-align: middle">نام نویسندگان</td>
        <td style="vertical-align: middle">عنوان ژورنال</td>
        <td style="vertical-align: middle">نام ناشر</td>
        <td style="vertical-align: middle">نوع ژورنال</td>
        <td style="vertical-align: middle">نوع مستخرج بودن</td>
        <td style="vertical-align: middle">تاریخ چاپ</td>
        <td style="vertical-align: middle">ISSN</td>
        <td style="vertical-align: middle">IF</td>
        <td style="vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $journals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->paper->title); ?>  </td>
            <td style=" vertical-align: middle">
                <?php $__currentLoopData = $item->paper->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($author->name); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td style=" vertical-align: middle"><?php echo e($item->name); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->publisher); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->paper->excerpt->name); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->jtype->name); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e(\Morilog\Jalali\Jalalian::forge($item->paper->publish_date)->format('Y/m/d')); ?></td>
            <td class="persian-num"  style=" vertical-align: middle"><?php echo e($item->issn); ?></td>
            <td class="persian-num"  style=" vertical-align: middle"><?php echo e($item->IFactor); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->paper->term->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="12" style="border: none; font-size: 12pt" class="border-bottom"><b>مقالات کنفرانسی</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <td style="vertical-align: middle">نام مقاله</td>
        <td style="vertical-align: middle">نام نویسندگان</td>
        <td style="vertical-align: middle">عنوان کنفرانس</td>
        <td style="vertical-align: middle">نام برگزارکننده</td>
        <td style="vertical-align: middle">نوع کنفرانس</td>
        <td style="vertical-align: middle">دوره برگزاری</td>
        <td style="vertical-align: middle">نوع مستخرج بودن</td>
        <td style="vertical-align: middle">تاریخ چاپ</td>
        <td style="vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $conferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->paper->title); ?>  </td>
            <td style=" vertical-align: middle">
                <?php $__currentLoopData = $item->paper->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($author->name); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td style=" vertical-align: middle"><?php echo e($item->name); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->organizer); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->paper->excerpt->name); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->conftype->name); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->period); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e(\morilog\jalali\Jalalian::forge($item->paper->publish_date)->format('Y/m/d')); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->paper->term->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="12" style="border: none; font-size: 12pt" class="border-bottom"><b>کتاب ها</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <td style=" vertical-align: middle">نام کتاب</td>
        <td style=" vertical-align: middle">نام نویسندگان</td>
        <td style=" vertical-align: middle">نوع کتاب</td>
        <td style=" vertical-align: middle">نام ناشر</td>
        <td style=" vertical-align: middle">موضوع کتاب</td>
        <td style=" vertical-align: middle">نوع مستخرج بودن</td>
        <td style=" vertical-align: middle">تاریخ چاپ</td>
        <td style=" vertical-align: middle">ردیف چاپ</td>
        <td style=" vertical-align: middle">تیراژ</td>
        <td style=" vertical-align: middle">تعداد صفحات</td>
        <td style=" vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->title); ?>  </td>
            <td style=" vertical-align: middle">
                <?php $__currentLoopData = $item->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($author->name); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td style=" vertical-align: middle"><?php echo e($item->booktype->name); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->publisher); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->subject); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->excerpt->name); ?></td>
            <td style=" vertical-align: middle"><?php echo e(\Morilog\Jalali\Jalalian::forge($item->publish_year)->format('Y/m/d')); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->publish_number); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->copy_number); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->pages); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->term->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="8" style="border: none; font-size: 12pt" class="border-bottom"><b>طرح های پژوهشی و فناوری</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <td style=" vertical-align: middle">عنوان طرح پژوهشی</td>
        <td style=" vertical-align: middle">نام نویسندگان</td>
        <td style=" vertical-align: middle">نوع طرح پژوهشی</td>
        <td style=" vertical-align: middle">بودجه طرح پژوهشی(ریال)</td>
        <td style=" vertical-align: middle">سازمان طرف قرارداد</td>
        <td style=" vertical-align: middle">تاریخ دفاع</td>
        <td style=" vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->title); ?>  </td>
            <td style=" vertical-align: middle">
                <?php $__currentLoopData = $item->authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e($author->name); ?>,
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <td style=" vertical-align: middle"><?php echo e($item->projectType->name); ?></td>
            <td  class="persian-num" style=" vertical-align: middle"><?php echo e($item->budget); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->organization); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e(\Morilog\Jalali\Jalalian::forge($item->defense_date)->format('Y/m/d')); ?></td>
            <td  class="persian-num" style=" vertical-align: middle"><?php echo e($item->term->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="7" style="border: none; font-size: 12pt" class="border-bottom"><b>اختراعات و ابداعات و نوآوری ها</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <td style=" vertical-align: middle">عنوان اختراع</td>
        <td style=" vertical-align: middle">نوع اختراع</td>
        <td style=" vertical-align: middle">سمت در تیم</td>
        <td style=" vertical-align: middle">مرحع تایید کننده</td>
        <td style=" vertical-align: middle">تاریخ ثبت یا صدور تاییدیه</td>
        <td style=" vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $inventions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->title); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->inventionType->name); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->post); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->authorities); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e(\Morilog\Jalali\Jalalian::forge($item->submit_date)->format('Y/m/d')); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->term->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="7" style="border: none; font-size: 12pt" class="border-bottom"><b>داوری مجلات و نظارت بر طرح های پژوهشی</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <td style=" vertical-align: middle">عنوان اثر داوری شده</td>
        <td style=" vertical-align: middle">نوع اثر داوری شده</td>
        <td style=" vertical-align: middle">نام مجله</td>
        <td style=" vertical-align: middle">ISSN</td>
        <td style=" vertical-align: middle">تاریخ داوری</td>
        <td style=" vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $referes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->title); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->refereeType->name); ?></td>
            <td style=" vertical-align: middle"><?php echo e(is_null($item->journal_name) ? '-' : $item->journal_name); ?></td>
            <td style=" vertical-align: middle"><?php echo e(is_null($item->journal_issn) ? '-' : $item->journal_name); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e(\Morilog\Jalali\Jalalian::forge($item->referee_date)->format('Y/m/d')); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->term->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="6" style="border: none; font-size: 12pt" class="border-bottom"><b>کرسی های نظریه پردازی</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <td style=" vertical-align: middle">عنوان کرسی نظریه پزداری</td>
        <td style=" vertical-align: middle">نوع کرسی</td>
        <td style=" vertical-align: middle">محل برگزاری</td>
        <td style=" vertical-align: middle">تاریخ ارائه</td>
        <td style=" vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $teds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->title); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->TEDType->name); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->location); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e(\Morilog\Jalali\Jalalian::forge($item->presentation_date)->format('Y/m/d')); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->term->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="5" style="border: none; font-size: 12pt" class="border-bottom"><b>پایان نامه ها</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <td style=" vertical-align: middle">عنوان پایان نامه</td>
        <td style=" vertical-align: middle">نوع پایان نامه</td>
        <td style=" vertical-align: middle">تاریخ تصویب شورای</td>
        <td style=" vertical-align: middle">تاریخ دفاع</td>
        <td style=" vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $theses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->title); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->thesisType->name); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e(is_null($item->council_aprovedate)? '-':\Morilog\Jalali\Jalalian::forge($item->council_aprovedate)->format('Y/m/d')); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e(is_null($item->defense_date)? '-':\Morilog\Jalali\Jalalian::forge($item->defense_date)->format('Y/m/d')); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->term->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="8" style="border: none; font-size: 12pt" class="border-bottom"><b>جوایز و افتخارات</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <td style=" vertical-align: middle">عنوان جشنواره، رقابت و یا مراسم</td>
        <td style=" vertical-align: middle">عنوان جایزه</td>
        <td style=" vertical-align: middle">نوع جشنواره، رقابت یا مراسم</td>
        <td style=" vertical-align: middle">رتبه کسب شده</td>
        <td style=" vertical-align: middle">دوره برگزاری</td>
        <td style=" vertical-align: middle">تاریخ برگزاری</td>
        <td style=" vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $rewards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->title); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->name); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->type); ?></td>
            <td style=" vertical-align: middle">
                <?php if($item->place==1): ?>
                    اول
                <?php elseif($item->place==2): ?>
                    دوم
                <?php else: ?>
                    سوم
                <?php endif; ?>
            </td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->period); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e(\Morilog\Jalali\Jalalian::forge($item->holding_date)->format('Y/m/d')); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->term->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="6" style="border: none; font-size: 12pt" class="border-bottom"><b>بودجه های تحقیقاتی جذب شده</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <td style=" vertical-align: middle">عنوان بودجه جذب شده</td>
        <td style=" vertical-align: middle">میزان بودجه(دلار یا ریال)</td>
        <td style=" vertical-align: middle">نوع بودجه</td>
        <td style=" vertical-align: middle">تاریخ جذب</td>
        <td style=" vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $grants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->title); ?>  </td>
            <td class="persian-num"  style=" vertical-align: middle"><?php echo e($item->budget); ?>

                <?php if($item->type==0): ?>
                    ریال
                <?php else: ?>
                    دلار
                <?php endif; ?></td>
            <td style=" vertical-align: middle">
                <?php if($item->type==0): ?>
                    داخلی
                <?php else: ?>
                    خارجی
                <?php endif; ?>
            </td>
            <td class="persian-num"  style=" vertical-align: middle"><?php echo e(\Carbon\Carbon::parse($item->submit_date)->format('Y-m-d')); ?></td>
            <td class="persian-num"  style=" vertical-align: middle"><?php echo e(arabic_w2e($item->term->name)); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="7" style="border: none; font-size: 12pt" class="border-bottom"><b>دوره ها</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <td style=" vertical-align: middle">عنوان دوره</td>
        <td style=" vertical-align: middle">نقش در دروه</td>
        <td style=" vertical-align: middle">سازمان برگزار کننده</td>
        <td style=" vertical-align: middle">مدت دوره</td>
        <td style=" vertical-align: middle">تاریخ برگزاری</td>
        <td style=" vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->title); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->role); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->organization); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->duration); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e(\Morilog\Jalali\Jalalian::forge($item->holding_date)->format('Y/m/d')); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->term->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<table class="table table-bordered table-sm"  style=" border-collapse: collapse;" >
    <tr>
        <td colspan="7" style="border: none; font-size: 12pt" class="border-bottom"><b>جزوات و اسلایدها</b></td>
    </tr>

    <tr >
        <td style="text-align: center; vertical-align: middle">ردیف</td>
        <th>عنوان جزوه یا اسلاید</th>
        <th>نام درس</th>
        <th>نوع جزوه یا اسلاید</th>
        <th>مقطع</th>
        <th>تاریخ تالیف</th>
        <td style=" vertical-align: middle">ترم</td>
    </tr>
    <tbody>
    <?php
        $counter = 1;
        ?>
    <?php $__currentLoopData = $booklets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td class="persian-num" style="text-align: center; vertical-align: middle"><?php echo e($counter++); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->title); ?>  </td>
            <td style=" vertical-align: middle"><?php echo e($item->name); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->booklet_type); ?></td>
            <td style=" vertical-align: middle"><?php echo e($item->degree->name); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e(\Morilog\Jalali\Jalalian::forge($item->compilation_date)->format('Y/m/d')); ?></td>
            <td class="persian-num" style=" vertical-align: middle"><?php echo e($item->term->name); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<br>
<br>
<br>
<br>
<p style="text-align: center">
    نام و نام خانوادگی:<br>
    تاریخ:<br>
    امضاء
</p>
</body>
</html>

