(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["noprefetch-Roman-bcmap"],{

/***/ "./node_modules/raw-loader/index.js!./node_modules/pdfjs-dist/cmaps/Roman.bcmap":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader!./node_modules/pdfjs-dist/cmaps/Roman.bcmap ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\u0002�RCopyright 1990-2009 Adobe Systems Incorporated.\nAll rights reserved.\nSee ./LICENSE\u0000\u0001\u0000�`\u0001 ^�g"

/***/ })

}]);