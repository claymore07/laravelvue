<template>

</template>

<script>
    export default {
        name: "Logout",
        created(){
            User.logout();
        }
    }
</script>

<style scoped>

</style>
