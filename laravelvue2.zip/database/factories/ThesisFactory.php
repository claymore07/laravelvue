<?php

use Faker\Generator as Faker;

$factory->define(App\Models\Thesis::class, function (Faker $faker) {
    return [
        //
    ];
});
