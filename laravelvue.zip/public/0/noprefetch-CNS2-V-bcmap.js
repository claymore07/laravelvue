(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["noprefetch-CNS2-V-bcmap"],{

/***/ "./node_modules/raw-loader/index.js!./node_modules/pdfjs-dist/cmaps/CNS2-V.bcmap":
/*!******************************************************************************!*\
  !*** ./node_modules/raw-loader!./node_modules/pdfjs-dist/cmaps/CNS2-V.bcmap ***!
  \******************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = "\u0003�RCopyright 1990-2009 Adobe Systems Incorporated.\nAll rights reserved.\nSee ./LICENSE�\u0006CNS2-H"

/***/ })

}]);