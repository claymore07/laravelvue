<template>
    <div class="container">
        <div class="row justify-content-center text-right text-rtl">
            <div class="col-md-8">
                <div class="card card-default">
                    <div class="card-header">داشبورد پژوهشی</div>

                    <div class="card-body">
                        <u>{{$parent.user.profile.Fname+' '+$parent.user.profile.Lname }}</u><br>
                        <br>
                        به سامانه پژوهشی دانشگاه خوش آمدید.
                        <br>
                        شما آخرین بار در تاریخ
                        <u>{{$parent.user.updated_at | myDate}}</u>
                        به سامانه مراجعه نموده اید.
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "Dashboard",
        mounted() {
            console.log('Dashboard Component mounted.')
        }
    }
</script>
